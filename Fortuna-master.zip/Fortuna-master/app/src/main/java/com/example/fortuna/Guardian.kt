package com.example.fortuna


data class Guardian(var name: String = "", var phone: String = "", var key: String = "", var uid: String = "")